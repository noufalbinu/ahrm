
<p>"Hello " <?php echo $name; ?></p>
<p>" Your CV succefully Submitted to <?php echo $package; ?>. We will inform you of further updates." ;</p>